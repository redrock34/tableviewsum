//
//  ViewController.swift
//  kurr
//
//  Created by John Zalubski on 8/18/20.
//  Copyright © 2020 John Zalubski. All rights reserved.
//
import UIKit
 
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
 
    var numberOfRows = 3
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { numberOfRows }
 
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { 118 }
 
    var tableView = UITableView()
    var selectedIndexPath = IndexPath(row: 0, section: 0)
 
    override func viewDidLoad() {
        super.viewDidLoad()

        setTableVIew()
        calculateSum()
    }

    func calculateSum() {

        var sum = 0
        for row in 0..<numberOfRows {
            let indexPath = IndexPath(row: row, section: 0)
            let cell = tableView.cellForRow(at: indexPath) as! CustomTableViewCell

            sum += Int(cell.lbl.text ?? "") ?? 0
        }
        print(sum)
    }
 
    func setTableVIew(){
    
          
         
       
        
        let VCframe = view.frame
        let height = VCframe.height * 0.8
           
        let widthx = VCframe.width
 
   
             tableView.frame = CGRect(x: 10, y: 0, width: widthx - 20, height: height)
          
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
  
      
        tableView.register(CustomTableViewCell.self, forCellReuseIdentifier: "cell")
    }
 
 
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
       cell.lbl.text = "\(indexPath.row)"
    
 
       return cell
   }
 
 
 
    
}
class CustomTableViewCell: UITableViewCell {
    lazy var backView : UIView = {
      let view = UIView(frame: CGRect(x: 10, y: 6, width: self.frame.width  , height: 110))
      view.backgroundColor = .green
      print(self.frame.width)
          return view
      }()
      
 
      
      override func layoutSubviews() {
         backView.clipsToBounds = true
         backView.frame =  CGRect(x: 0, y: 6, width: bounds.maxX  , height: 110)
   
 
      }
    lazy var lbl : UILabel = {
        let press = UILabel(frame: CGRect(x: 0, y: 3, width: 120 , height: 50))
        press.backgroundColor = .yellow
        press.text = String("1")
            
        return press
    }()
 
   
 
 
 
 
 
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(animated, animated: true)
        addSubview(backView)
    
        backView.addSubview(lbl)
    }
}
